<?php

/*
 * Model ::  Service
 * Table ::  services
 */

class Service extends AppModel {

    public $name = 'Service';
//    public $validate = array(
//        'category' => array(
//            'rule' => 'notEmpty',
//            'message' => 'Please select category'
//        ),
//        'name' => array(
//            'rule' => 'notEmpty',
//            'message' => 'Please enter name'
//        ),
//        'phone' => array(
//            'notEmpty' => array(
//                'rule' => 'notEmpty',
//                'message' => 'Please enter phone'
//            )/*,
//            'phone' => array(
//                'rule' => 'phone',
//                'message' => 'Please enter a valid phone number'
//            )*/
//        ),
//        'email' => array(
//            'rule' => 'email',
//            'message' => 'Please enter a valid email'
//        ),
//        'website' => array(
//            'rule' => 'notEmpty',
//            'message' => 'Please enter website'
//        ),
//        'region' => array(
//            'rule' => 'notEmpty',
//            'message' => 'Please enter region'
//        ),
//        'district' => array(
//            'rule' => 'notEmpty',
//            'message' => 'Please enter district'
//        )
//    );
}
