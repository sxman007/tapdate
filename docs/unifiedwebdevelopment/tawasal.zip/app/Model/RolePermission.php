<?php
class RolePermission extends AppModel{
    public $name = 'RolePermission';
}

