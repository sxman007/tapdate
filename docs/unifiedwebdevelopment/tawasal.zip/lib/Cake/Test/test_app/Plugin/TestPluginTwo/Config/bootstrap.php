<?php
Configure::write('CakePluginTest.test_plugin_two.bootstrap', 'loaded plugin two bootstrap');