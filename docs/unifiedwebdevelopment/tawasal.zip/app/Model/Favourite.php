<?php

/*
 * Model ::  Favourite
 * Table ::  favourites
 */

class Favourite extends AppModel {

    public $name = 'Favourite';

}
