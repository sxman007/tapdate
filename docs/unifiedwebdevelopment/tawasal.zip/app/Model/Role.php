<?php
class Role extends AppModel{
    public $name = 'Role';
   
}

