<?php

/*
 * Model ::  Content
 * Table ::  contents
 */

class Content extends AppModel {

    public $name = 'Content';

}
